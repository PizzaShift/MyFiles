﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OfficePartTests.cs" company="FA">
//   Fernando Andreu
// </copyright>
// <summary>
//   Defines the OfficePartTests type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace OfficeRibbonXEditor.Models
{
    using NUnit.Framework;

    [TestFixture]
    public class OfficePartTests
    {

    }
}